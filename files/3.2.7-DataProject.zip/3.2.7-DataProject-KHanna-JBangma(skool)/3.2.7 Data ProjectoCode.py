'''Kevin Hanna and Jaclynn Bangma
        3.2.7 Data Project'''

        #REMEMBER TO CHANGE THE CD TO FILE LOCATION :D
import os.path as os
width = 0.75 #width for graph

directory = os.dirname(os.abspath(__file__))#Gets file location
filename = os.join(directory, '# of Deaths by sickness per State.csv')#Stores in variable
filename1 = os.join(directory, 'Doctors per State.csv')
datafile = open(filename,'r')#opens and enables reading in variable
datafile1 = open(filename1,'r')
data = datafile.readlines()#reads in variable
data1 = datafile1.readlines()
death = []#lists for data
state = []      
state1 = []
docs = []    

for line in data[5:25]:#first 25 states
    numStates,numDeaths = line.split(',')#slices data into 2 sets
    state.append(numStates)#adds names of states to state list
    try:
        death.append(int(numDeaths))#adds death data to list 
    except ValueError:
        pass #skips over all unusable data 
        
for line in data1[5:25]:
    numStates,null,null1,numDocs = line.split(',')
    state1.append(numStates)
    try:
        docs.append(int(numDocs))
    except ValueError:
        pass

import numpy as np     #Creates a a list of numbers for all 25 states in 'states' to let the bar chart have a set of integers to work

number = np.arange(len(state)) 
number1 = np.arange(len(state1))


import matplotlib.pyplot as plt
#creates graphs
fig, ax  = plt.subplots()
plt.bar(number, death,width, align='center',)
plt.xticks(number,state, rotation = 'vertical')
plt.ylabel('# of Deaths by Pnuemonia and Influenza in US States (in Thousands)')
plt.xlabel('Various States')
plt.title('# of Deaths from Illness in Various States')
plt.show()

fig1, ax1 = plt.subplots()
plt.bar(number1, docs,width, align='center',)
plt.xticks(number, state1,  rotation = 'vertical')
plt.ylabel('# of Doctors in US States')
plt.xlabel('Various States')
plt.title('# of Doctors in Various States ')
plt.show()


